package classwork;

public interface Smoking {
    public void Smoke();
}
