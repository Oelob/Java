package classwork;

public interface Game {
    public void Gaming();
    
}
